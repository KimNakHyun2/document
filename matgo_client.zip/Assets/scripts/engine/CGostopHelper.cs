using System.Collections;
using System.Collections.Generic;

public static class CGostopHelper
{
    //public static bool is_exist_same_card(List<CFloorSlot> floor_slots, CCard card)
    //{
    //    return floor_slots[card.number].cards.Exists(obj => obj.position == card.position);
    //}
}
